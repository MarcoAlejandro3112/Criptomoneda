module.exports = {

    database: {
        user: 'sa',
        password: 'acmon',
        server: 'LAPTOP-1LEAIUDF',
        port: parseInt('1433'),
        database: 'dbNewOne',
        "options": {
        "encrypt": true,
        "enableArithAbort": true
    },
    }
};